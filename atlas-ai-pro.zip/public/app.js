const state = {
  messages: [],
  conversations: [],
  activeId: null,
  sourcesByMessage: {},
  streaming: false,
  settings: {
    webSearch: true,
    research: false,
    model: "openai/gpt-oss-120b:fastest",
    temperature: 0.6,
    maxTokens: 1400,
    topic: "general",
    timeRange: ""
  }
};

const $ = (id) => document.getElementById(id);

const els = {
  sidebar: $("sidebar"),
  history: $("history"),
  welcome: $("welcome"),
  chat: $("chat"),
  input: $("messageInput"),
  send: $("sendBtn"),
  web: $("webSearchToggle"),
  research: $("researchToggle"),
  status: $("searchStatus"),
  title: $("conversationTitle"),
  systemDot: $("systemDot"),
  systemText: $("systemText"),
  systemModel: $("systemModel"),
  overlay: $("overlay"),
  modal: $("settingsModal"),
  model: $("modelInput"),
  temperature: $("temperatureInput"),
  temperatureValue: $("temperatureValue"),
  maxTokens: $("maxTokensInput"),
  maxTokensValue: $("maxTokensValue"),
  topic: $("topicInput"),
  timeRange: $("timeRangeInput")
};

function uid() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

function escapeHTML(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function renderMarkdown(text) {
  let s = escapeHTML(text);

  const codeBlocks = [];
  s = s.replace(/```([\w+-]*)\n([\s\S]*?)```/g, (_, lang, code) => {
    const id = `code-${codeBlocks.length}`;
    codeBlocks.push({ id, lang, code });
    return `@@CODE_${id}@@`;
  });

  s = s.replace(/`([^`]+)`/g, '<span class="inline-code">$1</span>');

  s = s.replace(
    /^(#{4})\s+(.+)$/gm,
    "<h4>$2</h4>"
  ).replace(
    /^(#{3})\s+(.+)$/gm,
    "<h3>$2</h3>"
  );

  s = s.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
  s = s.replace(/\*(.+?)\*/g, "<em>$1</em>");

  s = s.replace(
    /^\s*[-*]\s+(.+)$/gm,
    "<li>$1</li>"
  );

  s = s.replace(
    /(<li>[\s\S]*?<\/li>)(?!\s*<li>)/g,
    (match) => `<ul>${match}</ul>`
  );

  s = s.replace(
    /^\s*>\s?(.+)$/gm,
    "<blockquote>$1</blockquote>"
  );

  s = s.replace(
    /\[(S\d+)\]/g,
    (_, id) => `<a class="citation" href="#source-${id}" data-source="${id}">${id}</a>`
  );

  s = s.replace(
    /\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,
    (_, label, url) => `<a href="${url}" target="_blank" rel="noreferrer">${label}</a>`
  );

  s = s
    .split(/\n{2,}/)
    .map((block) => {
      if (
        block.startsWith("<h3>") ||
        block.startsWith("<h4>") ||
        block.startsWith("<ul>") ||
        block.startsWith("<blockquote>") ||
        block.includes("@@CODE_")
      ) {
        return block;
      }
      return `<p>${block.replace(/\n/g, "<br />")}</p>`;
    })
    .join("");

  for (const item of codeBlocks) {
    const safeCode = item.code
      .replaceAll("&amp;", "&")
      .replaceAll("&lt;", "<")
      .replaceAll("&gt;", ">")
      .replaceAll("&quot;", '"')
      .replaceAll("&#039;", "'");

    const html = `
      <div class="code-wrap">
        <button class="copy-code" data-copy="${encodeURIComponent(safeCode)}">Copy</button>
        <code class="code-block">${escapeHTML(safeCode)}</code>
      </div>
    `;

    s = s.replace(`@@CODE_${item.id}@@`, html);
  }

  return s;
}

function nowTime() {
  return new Intl.DateTimeFormat([], {
    hour: "2-digit",
    minute: "2-digit"
  }).format(new Date());
}

function saveApp() {
  localStorage.setItem(
    "atlas-ai-state",
    JSON.stringify({
      conversations: state.conversations,
      settings: state.settings
    })
  );
}

function loadApp() {
  try {
    const saved = JSON.parse(localStorage.getItem("atlas-ai-state") || "null");

    if (saved?.conversations) state.conversations = saved.conversations;
    if (saved?.settings) {
      state.settings = {
        ...state.settings,
        ...saved.settings
      };
    }

    els.web.checked = state.settings.webSearch;
    els.research.checked = state.settings.research;
    els.model.value = state.settings.model;
    els.temperature.value = state.settings.temperature;
    els.maxTokens.value = state.settings.maxTokens;
    els.topic.value = state.settings.topic;
    els.timeRange.value = state.settings.timeRange;

    updateSettingLabels();
    renderHistory();

    if (state.conversations.length) {
      openConversation(state.conversations[0].id);
    } else {
      createConversation(false);
    }
  } catch {
    createConversation(false);
  }
}

function createConversation(render = true) {
  const conversation = {
    id: uid(),
    title: "New conversation",
    createdAt: Date.now(),
    messages: []
  };

  state.conversations.unshift(conversation);
  state.activeId = conversation.id;
  state.messages = conversation.messages;
  state.sourcesByMessage = {};
  els.title.textContent = conversation.title;

  if (render) {
    renderChat();
    renderHistory();
  }
  saveApp();
}

function getActiveConversation() {
  return state.conversations.find((x) => x.id === state.activeId);
}

function openConversation(id) {
  const found = state.conversations.find((x) => x.id === id);
  if (!found) return;

  state.activeId = found.id;
  state.messages = found.messages;
  state.sourcesByMessage = {};

  els.title.textContent = found.title;
  renderChat();
  renderHistory();

  if (window.innerWidth <= 760) els.sidebar.classList.remove("open");
}

function renderHistory() {
  els.history.innerHTML = "";

  for (const conversation of state.conversations.slice(0, 30)) {
    const item = document.createElement("div");
    item.className = `history-item ${conversation.id === state.activeId ? "active" : ""}`;
    item.textContent = conversation.title;
    item.title = conversation.title;
    item.addEventListener("click", () => openConversation(conversation.id));
    els.history.appendChild(item);
  }
}

function renderChat() {
  els.chat.innerHTML = "";

  if (!state.messages.length) {
    els.welcome.classList.remove("hidden");
    return;
  }

  els.welcome.classList.add("hidden");

  for (const message of state.messages) {
    renderMessageElement(message);
  }

  scrollToBottom();
}

function renderMessageElement(message, options = {}) {
  const wrapper = document.createElement("article");
  wrapper.className = `message ${message.role}`;
  wrapper.dataset.messageId = message.id || "";

  const avatar = document.createElement("div");
  avatar.className = "message-avatar";
  avatar.textContent = message.role === "user" ? "YOU" : "AI";

  const contentWrap = document.createElement("div");

  const meta = document.createElement("div");
  meta.className = "message-meta";
  meta.innerHTML = `
    <span class="message-role">${message.role === "user" ? "You" : "Atlas"}</span>
    <span class="message-time">${escapeHTML(message.time || nowTime())}</span>
  `;

  const body = document.createElement("div");
  body.className = "message-body";

  if (options.streaming) {
    body.textContent = "";
  } else if (message.role === "user") {
    body.textContent = message.content;
  } else {
    body.innerHTML = renderMarkdown(message.content);
  }

  contentWrap.appendChild(meta);
  contentWrap.appendChild(body);

  if (message.role === "assistant" && !options.streaming) {
    const actions = document.createElement("div");
    actions.className = "message-actions";

    const copyBtn = document.createElement("button");
    copyBtn.className = "message-action";
    copyBtn.textContent = "Copy";
    copyBtn.addEventListener("click", async () => {
      await navigator.clipboard.writeText(message.content);
      copyBtn.textContent = "Copied";
      setTimeout(() => (copyBtn.textContent = "Copy"), 1000);
    });

    actions.appendChild(copyBtn);
    contentWrap.appendChild(actions);

    const sources = state.sourcesByMessage[message.id];
    if (sources?.length) {
      contentWrap.appendChild(renderSources(sources));
    }
  }

  wrapper.appendChild(avatar);
  wrapper.appendChild(contentWrap);
  els.chat.appendChild(wrapper);

  return { wrapper, body };
}

function renderSources(sources) {
  const box = document.createElement("div");
  box.className = "sources";

  const title = document.createElement("div");
  title.className = "sources-title";
  title.textContent = `${sources.length} web sources`;
  box.appendChild(title);

  const list = document.createElement("div");
  list.className = "source-list";

  sources.forEach((source, index) => {
    const card = document.createElement("a");
    card.className = "source-card";
    card.id = `source-S${index + 1}`;
    card.href = source.url;
    card.target = "_blank";
    card.rel = "noreferrer";
    card.innerHTML = `
      <div>
        <div class="source-title">[S${index + 1}] ${escapeHTML(source.title || source.url)}</div>
        <div class="source-domain">${escapeHTML(source.domain || "")}</div>
      </div>
      <div class="source-index">${index + 1}</div>
    `;
    list.appendChild(card);
  });

  box.appendChild(list);
  return box;
}

function scrollToBottom() {
  els.chat.scrollTop = els.chat.scrollHeight;
}

function updateSettingLabels() {
  els.temperatureValue.textContent = Number(els.temperature.value).toFixed(1);
  els.maxTokensValue.textContent = els.maxTokens.value;
}

function setStatus(message = "") {
  els.status.textContent = message;
}

function setTokenHint(message) {
  document.getElementById("tokenHint").textContent = message;
}

function autoResize() {
  els.input.style.height = "auto";
  els.input.style.height = `${Math.min(els.input.scrollHeight, 190)}px`;
}

function updateConversationTitle(question) {
  const conv = getActiveConversation();
  if (!conv) return;

  if (conv.messages.length > 1 || conv.title !== "New conversation") return;

  const title = question.replace(/\s+/g, " ").trim().slice(0, 48);
  conv.title = title || "New conversation";
  els.title.textContent = conv.title;

  renderHistory();
  saveApp();
}

async function sendMessage() {
  if (state.streaming) return;

  const text = els.input.value.trim();
  if (!text) return;

  if (!state.activeId) createConversation(false);

  state.streaming = true;
  els.send.disabled = true;

  const userMessage = {
    id: uid(),
    role: "user",
    content: text,
    time: nowTime()
  };

  state.messages.push(userMessage);
  updateConversationTitle(text);

  els.welcome.classList.add("hidden");
  renderMessageElement(userMessage);

  els.input.value = "";
  autoResize();

  const assistantId = uid();
  const assistant = {
    id: assistantId,
    role: "assistant",
    content: "",
    time: nowTime()
  };

  state.messages.push(assistant);

  const rendered = renderMessageElement(assistant, { streaming: true });
  const assistantBody = rendered.body;

  setStatus(
    state.settings.webSearch
      ? (state.settings.research ? "Starting deep research…" : "Searching and synthesizing…")
      : "Generating from model knowledge…"
  );

  scrollToBottom();

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: state.messages
          .filter((m) => m.id !== assistantId)
          .map(({ role, content }) => ({ role, content })),
        searchEnabled: state.settings.webSearch,
        researchMode: state.settings.research,
        model: state.settings.model,
        temperature: state.settings.temperature,
        maxTokens: state.settings.maxTokens,
        topic: state.settings.topic,
        timeRange: state.settings.timeRange || null
      })
    });

    if (!response.ok || !response.body) {
      throw new Error(`Server error: ${response.status}`);
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = "";
    let finalPayload = null;

    while (true) {
      const { value, done } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });

      const chunks = buffer.split("\n\n");
      buffer = chunks.pop() || "";

      for (const chunk of chunks) {
        const eventLine = chunk.split("\n").find((line) => line.startsWith("event:"));
        const dataLine = chunk.split("\n").find((line) => line.startsWith("data:"));

        if (!dataLine) continue;

        const event = eventLine ? eventLine.replace(/^event:\s*/, "") : "message";
        const data = JSON.parse(dataLine.replace(/^data:\s*/, ""));

        if (event === "status") {
          setStatus(data.message || "");
        }

        if (event === "sources") {
          state.sourcesByMessage[assistantId] = data.sources || [];
          if (data.sources?.length) {
            setStatus(`${data.sources.length} web sources found`);
          } else {
            setStatus("No web sources were returned.");
          }
        }

        if (event === "token") {
          assistant.content += data.text || "";
          assistantBody.innerHTML = renderMarkdown(assistant.content);
          scrollToBottom();
        }

        if (event === "done") {
          finalPayload = data;
        }

        if (event === "error") {
          throw new Error(data.message || "AI request failed.");
        }
      }
    }

    if (finalPayload?.sources?.length) {
      state.sourcesByMessage[assistantId] = finalPayload.sources;
    }

    assistantBody.innerHTML = renderMarkdown(assistant.content);

    // Add message action buttons + source cards after streaming is done.
    const contentWrap = rendered.wrapper.children[1];
    contentWrap.querySelector(".message-actions")?.remove();
    contentWrap.querySelector(".sources")?.remove();

    const actions = document.createElement("div");
    actions.className = "message-actions";

    const copyBtn = document.createElement("button");
    copyBtn.className = "message-action";
    copyBtn.textContent = "Copy";
    copyBtn.onclick = async () => {
      await navigator.clipboard.writeText(assistant.content);
      copyBtn.textContent = "Copied";
      setTimeout(() => (copyBtn.textContent = "Copy"), 1000);
    };

    actions.appendChild(copyBtn);
    contentWrap.appendChild(actions);

    const sources = state.sourcesByMessage[assistantId];
    if (sources?.length) {
      contentWrap.appendChild(renderSources(sources));
    }

    // Re-bind code-copy buttons created by markdown rendering.
    bindCopyButtons();

    const conv = getActiveConversation();
    if (conv) {
      conv.messages = state.messages;
    }

    saveApp();
    setStatus("");

  } catch (error) {
    assistant.content += `\n\n⚠️ ${error.message}`;
    assistantBody.innerHTML = renderMarkdown(assistant.content);
    setStatus("Request failed.");
  } finally {
    state.streaming = false;
    els.send.disabled = false;
    setTokenHint("Ready");
    bindCopyButtons();
    scrollToBottom();
  }
}

function bindCopyButtons() {
  document.querySelectorAll(".copy-code").forEach((button) => {
    if (button.dataset.bound === "1") return;
    button.dataset.bound = "1";

    button.addEventListener("click", async () => {
      const value = decodeURIComponent(button.dataset.copy || "");
      await navigator.clipboard.writeText(value);
      button.textContent = "Copied";
      setTimeout(() => (button.textContent = "Copy"), 1000);
    });
  });

  document.querySelectorAll(".citation").forEach((link) => {
    if (link.dataset.bound === "1") return;
    link.dataset.bound = "1";

    link.addEventListener("click", (event) => {
      event.preventDefault();
      const id = link.dataset.source;
      document.getElementById(`source-${id}`)?.scrollIntoView({
        behavior: "smooth",
        block: "center"
      });
    });
  });
}

async function checkHealth() {
  try {
    const response = await fetch("/api/health");
    const data = await response.json();

    const ready = data.ok && data.hfConfigured;

    els.systemDot.classList.toggle("online", ready);
    els.systemText.textContent = ready
      ? (data.webSearchConfigured ? "AI + Web search online" : "AI online — web search not configured")
      : "Configuration incomplete";

    els.systemModel.textContent = `Model: ${data.model || "unknown"}`;
  } catch {
    els.systemDot.classList.remove("online");
    els.systemText.textContent = "Server unavailable";
  }
}

function toggleSettings(show) {
  const visible = show ?? els.modal.classList.contains("hidden");
  els.modal.classList.toggle("hidden", !visible);
  els.overlay.classList.toggle("hidden", !visible);
}

$("newChatBtn").addEventListener("click", () => createConversation());

$("clearBtn").addEventListener("click", () => {
  if (!state.messages.length) return;
  state.messages = [];
  const conv = getActiveConversation();
  if (conv) conv.messages = [];
  state.sourcesByMessage = {};
  renderChat();
  saveApp();
});

$("exportBtn").addEventListener("click", () => {
  const data = state.messages
    .map((m) => `${m.role.toUpperCase()} — ${m.time}\n\n${m.content}`)
    .join(`\n\n${"---".repeat(15)}\n\n`);

  const blob = new Blob([data], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = `atlas-conversation-${new Date().toISOString().slice(0,10)}.txt`;
  a.click();

  URL.revokeObjectURL(url);
});

els.input.addEventListener("input", autoResize);

els.input.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    sendMessage();
  }
});

els.send.addEventListener("click", sendMessage);

els.web.addEventListener("change", () => {
  state.settings.webSearch = els.web.checked;
  saveApp();
});

els.research.addEventListener("change", () => {
  state.settings.research = els.research.checked;
  saveApp();
});

$("themeBtn").addEventListener("click", () => {
  document.body.classList.toggle("light");
});

$("settingsBtn").addEventListener("click", () => toggleSettings(true));
$("closeSettings").addEventListener("click", () => toggleSettings(false));
els.overlay.addEventListener("click", () => toggleSettings(false));

els.temperature.addEventListener("input", updateSettingLabels);
els.maxTokens.addEventListener("input", updateSettingLabels);

$("saveSettingsBtn").addEventListener("click", () => {
  state.settings.model = els.model.value;
  state.settings.temperature = Number(els.temperature.value);
  state.settings.maxTokens = Number(els.maxTokens.value);
  state.settings.topic = els.topic.value;
  state.settings.timeRange = els.timeRange.value;

  saveApp();
  toggleSettings(false);
});

$("mobileMenuBtn").addEventListener("click", () => {
  els.sidebar.classList.toggle("open");
});

document.querySelectorAll(".quick-card").forEach((card) => {
  card.addEventListener("click", () => {
    els.input.value = card.dataset.prompt || "";
    autoResize();
    els.input.focus();
  });
});

loadApp();
checkHealth();
bindCopyButtons();
