# Atlas AI — Professional Web-Connected AI Assistant

A full-stack JavaScript AI assistant using:

- Hugging Face Inference Providers for model inference
- Tavily Search API for current web retrieval
- Express 5 server
- HTML/CSS/JavaScript frontend
- Server-Sent Events for token streaming
- Source cards and inline citations
- Conversation history saved in localStorage
- Standard search and deep research modes

## Requirements

- Node.js 18+
- Hugging Face account + token with Inference Providers permission
- Tavily API key for web search

## Setup

1. Rename `.env.example` to `.env`.
2. Add your keys:

HF_TOKEN=...
TAVILY_API_KEY=...

3. Install packages:

npm install

4. Start:

npm start

5. Open:

http://localhost:3000

## Important

Do not publish `.env` or expose API keys in frontend JavaScript.

The system is a web-connected AI application, not a newly trained foundation model. Its intelligence comes from the selected pretrained model, while current information is added through web retrieval and source-aware synthesis.
